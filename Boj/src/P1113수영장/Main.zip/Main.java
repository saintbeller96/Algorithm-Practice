package P1113������;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {
	private static int N, M, Answer;
	private static int minH;
	private static int[][] map;
	private static int[][] water;
	private static boolean flag;
	private static int[] dr = { 1, -1, 0, 0 };
	private static int[] dc = { 0, 0, 1, -1 };

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer stk = new StringTokenizer(br.readLine());
		N = Integer.parseInt(stk.nextToken());
		M = Integer.parseInt(stk.nextToken());
		map = new int[N][M];
		water = new int[N][M];
		int max = 0;
		int min = 9;
		for (int i = 0; i < N; i++) {
			String str = br.readLine();
			for (int j = 0; j < M; j++) {
				map[i][j] = str.charAt(j) - '0';
				max = Math.max(max, map[i][j]);
				min = Math.min(min, map[i][j]);
			}
		}
		for (int h = min; h <= max; h++) {
			flag = false;
			find(h);
		}
		System.out.println(Answer);

	}

	private static void find(int h) {
		boolean[][] b = new boolean[N][M];
		for (int i = 1; i <= N - 2; i++) {
			for (int j = 1; j <= M - 2; j++) {
				if (map[i][j] == h) {
					b[i][j] = true;
					flag = false;
					minH = 9;
					DFS(b, i, j, h);
					print();
					print2();
				}
			}
		}
	}

	private static void DFS(boolean[][] b, int i, int j, int h) {
		if (map[i][j] == 0) {
			flag = true;
			return;
		}
		minH = howTall(b, i, j, h);
		for (int d = 0; d < 4; d++) {
			int r = i + dr[d];
			int c = j + dc[d];
			if (r >= 1 && r <= N - 2 && c >= 1 && c <= M - 2) {
				if (!b[r][c] && map[r][c] == h) {
					b[r][c] = true;
					int hh = howTall(b, i, j, h);
					minH = minH < hh ? minH : hh;
					DFS(b, r, c, h);
				}
			}
		}
		if (!flag) {
			int tmp = map[i][j];
			map[i][j] = minH;
			water[i][j] += minH - tmp;
		}

	}

	private static int howTall(boolean[][] b, int i, int j, int h) {
		int min = 9;
		for (int d = 0; d < 4; d++) {
			int r = i + dr[d];
			int c = j + dc[d];
			if (r >= 0 && r <= N - 1 && c >= 0 && c <= M - 1) {
				if (map[r][c] > h) {
					b[r][c] = true;
					min = Math.min(min, map[r][c]);
				}e
			}
		}
		return min;
	}

	private static void print() {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				System.out.print(" " + map[i][j]);
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

	private static void print2() {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				System.out.print(" " + water[i][j]);
			}
			System.out.println();
		}
		System.out.println("-------------------");
	}

}
